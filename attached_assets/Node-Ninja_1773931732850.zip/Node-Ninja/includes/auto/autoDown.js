/**
 * includes/auto/autoDown.js
 * Tự động tải media từ link chia sẻ trong chat Zalo.
 * Convert từ Auto/AutoDown.js của GwenDev_ZaloChat (ESM + MySQL) → CommonJS + settings.json
 */

const axios  = require("axios");
const path   = require("path");
const fs     = require("fs");
const { execFile, execSync } = require("child_process");
const { ThreadType } = require("zca-js");
const { sendVideo, sendVoice, tempDir } = require("../../utils/media/upload");

const SETTINGS_FILE = path.join(process.cwd(), "includes", "data", "settings.json");

// ============== LINK ==============//
const SUPPORTED_LINKS = [
    /tiktok\.com/, /douyin\.com/, /capcut\.com/, /threads\.com/, /threads\.net/,
    /instagram\.com/, /facebook\.com/, /espn\.com/, /pinterest\.com/, /imdb\.com/,
    /imgur\.com/, /ifunny\.co/, /izlesene\.com/, /reddit\.com/, /youtube\.com/,
    /youtu\.be/, /twitter\.com/, /x\.com/, /vimeo\.com/, /snapchat\.com/,
    /bilibili\.com/, /dailymotion\.com/, /sharechat\.com/, /likee\.video/,
    /linkedin\.com/, /tumblr\.com/, /hipi\.co\.in/, /telegram\.org/,
    /getstickerpack\.com/, /bitchute\.com/, /febspot\.com/, /9gag\.com/,
    /ok\.ru/, /rumble\.com/, /streamable\.com/, /ted\.com/, /sohu\.com/,
    /xvideos\.com/, /xnxx\.com/, /xiaohongshu\.com/, /ixigua\.com/, /weibo\.com/,
    /miaopai\.com/, /meipai\.com/, /xiaoying\.tv/, /nationalvideo\.com/,
    /yingke\.com/, /sina\.com\.cn/, /vk\.com/, /vk\.ru/, /soundcloud\.com/,
    /mixcloud\.com/, /spotify\.com/, /zingmp3\.vn/, /bandcamp\.com/
];

// ============== CHECK ON ==============//
function isAutoDownEnabled(threadId) {
    try {
        if (!fs.existsSync(SETTINGS_FILE)) return true;
        const data = JSON.parse(fs.readFileSync(SETTINGS_FILE, "utf-8"));
        if (data[threadId] && data[threadId].autodown !== undefined) {
            return data[threadId].autodown !== false;
        }
        if (data["__global"] && data["__global"].autodown !== undefined) {
            return data["__global"].autodown !== false;
        }
        return true;
    } catch {
        return true;
    }
}

// ============== HELPERS ==============//
async function downloadFile(url, filePath) {
    const response = await axios.get(url, {
        responseType: "arraybuffer",
        timeout: 30000,
        maxContentLength: 200 * 1024 * 1024,
    });
    fs.writeFileSync(filePath, Buffer.from(response.data));
    return response.data;
}

function getVideoMetadata(filePath) {
    return new Promise((resolve, reject) => {
        try {
            const out = execSync(
                `ffprobe -v error -show_format -show_streams -of json "${filePath}"`,
                { timeout: 15000 }
            ).toString();
            const data = JSON.parse(out);
            const videoStream = data.streams.find(s => s.codec_type === "video");
            if (!videoStream) return reject(new Error("Không tìm thấy video stream."));
            resolve({
                width: videoStream.width || 0,
                height: videoStream.height || 0,
                duration: Math.round(parseFloat(data.format.duration || 0))
            });
        } catch (e) {
            reject(e);
        }
    });
}

function processYouTubeVideo(inputPath, outputPath) {
    return new Promise((resolve, reject) => {
        try {
            execSync(
                `ffmpeg -y -i "${inputPath}" -preset veryfast -movflags +faststart -vf scale=640:-2 -c:v libx264 -c:a aac -b:v 700k -b:a 128k "${outputPath}"`,
                { timeout: 120000 }
            );
            resolve();
        } catch (e) {
            reject(e);
        }
    });
}

function convertToAac(inputPath, outputPath) {
    return new Promise((resolve, reject) => {
        try {
            execSync(`ffmpeg -y -i "${inputPath}" -acodec aac "${outputPath}"`, { timeout: 60000 });
            resolve();
        } catch (e) {
            reject(e);
        }
    });
}

function cleanupFiles(files, delay = 8000) {
    setTimeout(() => {
        files.forEach(file => {
            try { if (fs.existsSync(file)) fs.unlinkSync(file); } catch {}
        });
    }, delay);
}

// ============== START ==============//
function startAutoDown(api) {
    logInfo("[AutoDown] Đã khởi động.");

    api.listener.on("message", async (msg) => {
        const threadId   = msg.threadId;
        const threadType = msg.type;

        const content  = typeof msg.data?.content === "string" ? msg.data.content.trim() : "";
        const href     = typeof msg.data?.content?.href === "string" ? msg.data.content.href.trim() : "";
        const title    = typeof msg.data?.content?.title === "string" ? msg.data.content.title.trim() : "";
        const bodyText = typeof msg.message?.body === "string" ? msg.message.body.trim() : "";
        const body     = content || bodyText || href || title;

        if (!body || !/^https?:\/\/\S+/.test(body)) return;
        if (!SUPPORTED_LINKS.some(rx => rx.test(body))) return;
        if (!isAutoDownEnabled(threadId)) return;

        logInfo(`[AutoDown] Get Link: ${body}`);

        try {
            // Resolve short URLs (vt.tiktok.com, fb.watch, youtu.be, ...) → lấy URL thật
            let finalUrl = body;
            try {
                const headRes = await axios.get(body, {
                    maxRedirects: 10,
                    timeout: 15000,
                    validateStatus: () => true,
                });
                if (headRes.request?.res?.responseUrl) {
                    finalUrl = headRes.request.res.responseUrl;
                } else if (headRes.request?.responseURL) {
                    finalUrl = headRes.request.responseURL;
                }
            } catch {}

            logInfo(`[AutoDown] URL thật: ${finalUrl}`);

            let apiUrl;
            if (/instagram\.com|threads\.net|threads\.com/.test(finalUrl)) {
                apiUrl = `https://kemapis.eu.org/api/instagram/media?url=${encodeURIComponent(finalUrl)}`;
            } else {
                apiUrl = `https://api.zeidteam.xyz/media-downloader/atd2?url=${encodeURIComponent(finalUrl)}`;
            }

            const res  = await axios.get(apiUrl, { timeout: 60000 });
            const data = res.data;

            if (!data || !Array.isArray(data.medias) || data.medias.length === 0) {
                logWarn(`[AutoDown] Không có media: ${finalUrl}`);
                return;
            }

            const mediaTitle = data.title?.trim() || "🎬 Downloaded Content";
            const author     = data.author || data.unique_id || "Unknown";
            const source     = data.source || "unknown";

            fs.mkdirSync(tempDir, { recursive: true });

            // ============== TIKTOK ==============//
            if (["tiktok", "douyin"].includes(source) || /(?:vm\.)?tiktok\.com/.test(finalUrl)) {
                const hasVideo   = data.medias.some(m => m.type === "video");
                const isImageOnly = !hasVideo;

                if (isImageOnly) {
                    const attachments = [];
                    for (const [index, media] of data.medias.entries()) {
                        if (media.type === "image" && media.url) {
                            try {
                                const ext       = path.extname(media.url.split("?")[0]) || ".jpg";
                                const imagePath = path.join(tempDir, `ttimg_${Date.now()}_${index}${ext}`);
                                await downloadFile(media.url, imagePath);
                                attachments.push(imagePath);
                            } catch (err) { logWarn(`[AutoDown] Lỗi ảnh: ${err.message}`); }
                        }
                    }
                    if (attachments.length > 0) {
                        await api.sendMessage({
                            msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐓𝐢𝐤𝐓𝐨𝐤\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                            attachments, ttl: 500_000
                        }, threadId, threadType);
                        cleanupFiles(attachments);
                    }
                    const audio = data.medias.find(m => m.type === "audio" && m.url);
                    if (audio?.url) {
                        const tempPath = path.join(tempDir, `ttaudio_${Date.now()}`);
                        const aacPath  = `${tempPath}.aac`;
                        try {
                            await downloadFile(audio.url, tempPath);
                            await convertToAac(tempPath, aacPath);
                            await sendVoice(api, aacPath, threadId, threadType);
                        } catch (err) { logWarn(`[AutoDown] Lỗi audio: ${err.message}`); }
                        finally { cleanupFiles([tempPath, aacPath]); }
                    }
                    return;
                }

                const video = data.medias.find(m => m.type === "video" && m.quality?.includes("no_watermark"))
                           || data.medias.find(m => m.type === "video");
                if (!video?.url) return;

                const tmpPath = path.join(tempDir, `ttvid_${Date.now()}.mov`);
                let width = 720, height = 1280, duration = 0;
                try {
                    await downloadFile(video.url, tmpPath);
                    const meta = await getVideoMetadata(tmpPath);
                    width = meta.width; height = meta.height; duration = meta.duration;
                } catch (err) { logWarn(`[AutoDown] Lỗi metadata: ${err.message}`); }
                finally { cleanupFiles([tmpPath], 0); }

                await api.sendVideo({
                    videoUrl: video.url,
                    thumbnailUrl: video.thumbnail || data.thumbnail || video.url,
                    msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐓𝐢𝐤𝐓𝐨𝐤\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                    width, height, duration: duration * 1000, ttl: 500_000
                }, threadId, threadType);
                return;
            }

            // ============== DOUYIN ==============//
            if (source === "douyin" || /(?:v\.)?douyin\.com/.test(finalUrl)) {
                const hasVideo    = data.medias.some(m => m.type === "video");
                const isImageOnly = !hasVideo;

                if (isImageOnly) {
                    const attachments = [];
                    for (const [index, media] of data.medias.entries()) {
                        if (media.type === "image" && media.url) {
                            try {
                                const ext       = path.extname(media.url.split("?")[0]) || ".jpg";
                                const imagePath = path.join(tempDir, `dyimg_${Date.now()}_${index}${ext}`);
                                await downloadFile(media.url, imagePath);
                                attachments.push(imagePath);
                            } catch (err) { logWarn(`[AutoDown] Lỗi ảnh Douyin: ${err.message}`); }
                        }
                    }
                    if (attachments.length > 0) {
                        await api.sendMessage({
                            msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐃𝐨𝐮𝐲𝐢𝐧\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                            attachments, ttl: 500_000
                        }, threadId, threadType);
                        cleanupFiles(attachments);
                    }
                    const audio = data.medias.find(m => m.type === "audio" && m.url);
                    if (audio?.url) {
                        const tempPath = path.join(tempDir, `dyaudio_${Date.now()}`);
                        const aacPath  = `${tempPath}.aac`;
                        try {
                            await downloadFile(audio.url, tempPath);
                            await convertToAac(tempPath, aacPath);
                            await sendVoice(api, aacPath, threadId, threadType);
                        } catch (err) { logWarn(`[AutoDown] Lỗi audio Douyin: ${err.message}`); }
                        finally { cleanupFiles([tempPath, aacPath]); }
                    }
                    return;
                }

                const video = data.medias.find(m => m.type === "video" && m.quality?.includes("no_watermark"))
                           || data.medias.find(m => m.type === "video");
                if (!video?.url) return;

                const tmpPath = path.join(tempDir, `dyvid_${Date.now()}.mov`);
                let width = 720, height = 1280, duration = 0;
                try {
                    await downloadFile(video.url, tmpPath);
                    const meta = await getVideoMetadata(tmpPath);
                    width = meta.width; height = meta.height; duration = meta.duration;
                } catch (err) { logWarn(`[AutoDown] Lỗi metadata Douyin: ${err.message}`); }
                finally { cleanupFiles([tmpPath], 0); }

                await api.sendVideo({
                    videoUrl: video.url,
                    thumbnailUrl: video.thumbnail || data.thumbnail || video.url,
                    msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐃𝐨𝐮𝐲𝐢𝐧\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                    width, height, duration: duration * 1000, ttl: 500_000
                }, threadId, threadType);
                return;
            }

            // ============== FACEBOOK ==============//
            if (source === "facebook" || /facebook\.com/.test(finalUrl)) {
                const hasVideo    = data.medias.some(m => m.type === "video");
                const isImageOnly = !hasVideo;

                if (isImageOnly) {
                    const attachments = [];
                    for (const [index, media] of data.medias.entries()) {
                        if (media.type === "image" && media.url) {
                            try {
                                const ext       = path.extname(media.url.split("?")[0]) || ".jpg";
                                const imagePath = path.join(tempDir, `fbimg_${Date.now()}_${index}${ext}`);
                                await downloadFile(media.url, imagePath);
                                attachments.push(imagePath);
                            } catch (err) { logWarn(`[AutoDown] Lỗi ảnh FB: ${err.message}`); }
                        }
                    }
                    if (attachments.length > 0) {
                        await api.sendMessage({
                            msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                            attachments, ttl: 500_000
                        }, threadId, threadType);
                        cleanupFiles(attachments);
                    }
                    const audio = data.medias.find(m => m.type === "audio" && m.url);
                    if (audio?.url) {
                        const tempPath = path.join(tempDir, `fbaudio_${Date.now()}`);
                        const aacPath  = `${tempPath}.aac`;
                        try {
                            await downloadFile(audio.url, tempPath);
                            await convertToAac(tempPath, aacPath);
                            await sendVoice(api, aacPath, threadId, threadType);
                        } catch (err) { logWarn(`[AutoDown] Lỗi audio FB: ${err.message}`); }
                        finally { cleanupFiles([tempPath, aacPath]); }
                    }
                    return;
                }

                const video = data.medias.find(m => m.type === "video" && m.quality?.includes("no_watermark"))
                           || data.medias.find(m => m.type === "video");
                if (!video?.url) return;

                const tmpPath = path.join(tempDir, `fbvid_${Date.now()}.mov`);
                let width = 720, height = 1280, duration = 0;
                try {
                    await downloadFile(video.url, tmpPath);
                    const meta = await getVideoMetadata(tmpPath);
                    width = meta.width; height = meta.height; duration = meta.duration;
                } catch (err) { logWarn(`[AutoDown] Lỗi metadata FB: ${err.message}`); }
                finally { cleanupFiles([tmpPath], 0); }

                await api.sendVideo({
                    videoUrl: video.url,
                    thumbnailUrl: video.thumbnail || data.thumbnail || video.url,
                    msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                    width, height, duration: duration * 1000, ttl: 500_000
                }, threadId, threadType);
                return;
            }

            // ============== CAPCUT ==============//
            if (source === "capcut" || /capcut\.com/.test(finalUrl)) {
                const hasVideo    = data.medias.some(m => m.type === "video");
                const isImageOnly = !hasVideo;

                if (isImageOnly) {
                    const attachments = [];
                    for (const [index, media] of data.medias.entries()) {
                        if (media.type === "image" && media.url) {
                            try {
                                const ext       = path.extname(media.url.split("?")[0]) || ".jpg";
                                const imagePath = path.join(tempDir, `ccimg_${Date.now()}_${index}${ext}`);
                                await downloadFile(media.url, imagePath);
                                attachments.push(imagePath);
                            } catch (err) { logWarn(`[AutoDown] Lỗi ảnh CapCut: ${err.message}`); }
                        }
                    }
                    if (attachments.length > 0) {
                        await api.sendMessage({
                            msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐂𝐚𝐩𝐂𝐮𝐭\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                            attachments, ttl: 500_000
                        }, threadId, threadType);
                        cleanupFiles(attachments);
                    }
                    const audio = data.medias.find(m => m.type === "audio" && m.url);
                    if (audio?.url) {
                        const tempPath = path.join(tempDir, `ccaudio_${Date.now()}`);
                        const aacPath  = `${tempPath}.aac`;
                        try {
                            await downloadFile(audio.url, tempPath);
                            await convertToAac(tempPath, aacPath);
                            await sendVoice(api, aacPath, threadId, threadType);
                        } catch (err) { logWarn(`[AutoDown] Lỗi audio CapCut: ${err.message}`); }
                        finally { cleanupFiles([tempPath, aacPath]); }
                    }
                    return;
                }

                const video = data.medias.find(m => m.type === "video" && m.quality?.includes("no_watermark"))
                           || data.medias.find(m => m.type === "video");
                if (!video?.url) return;

                const tmpPath = path.join(tempDir, `ccvid_${Date.now()}.mov`);
                let width = 720, height = 1280, duration = 0;
                try {
                    await downloadFile(video.url, tmpPath);
                    const meta = await getVideoMetadata(tmpPath);
                    width = meta.width; height = meta.height; duration = meta.duration;
                } catch (err) { logWarn(`[AutoDown] Lỗi metadata CapCut: ${err.message}`); }
                finally { cleanupFiles([tmpPath], 0); }

                await api.sendVideo({
                    videoUrl: video.url,
                    thumbnailUrl: video.thumbnail || data.thumbnail || video.url,
                    msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐂𝐚𝐩𝐂𝐮𝐭\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                    width, height, duration: duration * 1000, ttl: 500_000
                }, threadId, threadType);
                return;
            }

            // ============== INSTAGRAM & THREADS ==============//
            if (["instagram", "threads"].includes(source) || /instagram\.com|threads\.net|threads\.com/.test(finalUrl)) {
                const platform   = /threads/.test(finalUrl) ? "𝐓𝐡𝐫𝐞𝐚𝐝𝐬" : "𝐈𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦";
                const hasVideo    = data.medias.some(m => m.type === "video");
                const isImageOnly = !hasVideo;

                if (isImageOnly) {
                    const attachments = [];
                    for (const [index, media] of data.medias.entries()) {
                        if (media.type === "image" && media.url) {
                            try {
                                const ext       = path.extname(media.url.split("?")[0]) || ".jpg";
                                const imagePath = path.join(tempDir, `igimg_${Date.now()}_${index}${ext}`);
                                await downloadFile(media.url, imagePath);
                                attachments.push(imagePath);
                            } catch (err) { logWarn(`[AutoDown] Lỗi ảnh IG: ${err.message}`); }
                        }
                    }
                    if (attachments.length > 0) {
                        await api.sendMessage({
                            msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: ${platform}\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                            attachments, ttl: 500_000
                        }, threadId, threadType);
                        cleanupFiles(attachments);
                    }
                    return;
                }

                const video = data.medias.find(m => m.type === "video");
                if (!video?.url) return;

                const tmpPath = path.join(tempDir, `igvid_${Date.now()}.mov`);
                let width = 720, height = 1280, duration = 0;
                try {
                    await downloadFile(video.url, tmpPath);
                    const meta = await getVideoMetadata(tmpPath);
                    width = meta.width; height = meta.height; duration = meta.duration;
                } catch (err) { logWarn(`[AutoDown] Lỗi metadata IG: ${err.message}`); }
                finally { cleanupFiles([tmpPath], 0); }

                await api.sendVideo({
                    videoUrl: video.url,
                    thumbnailUrl: video.thumbnail || data.thumbnail || video.url,
                    msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: ${platform}\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                    width, height, duration: duration * 1000, ttl: 500_000
                }, threadId, threadType);
                return;
            }

            // ============== BILIBILI ==============//
            if (source === "bilibili" || /bilibili\.com/.test(finalUrl)) {
                const MAX_SIZE_BYTES = 500 * 1024 * 1024;
                const candidates = data.medias.filter(m => m.type?.startsWith("video") && m.url);
                let bestVideo = null;
                for (const video of candidates) {
                    try {
                        const head = await axios.head(video.url, { timeout: 10000 });
                        const size = parseInt(head.headers["content-length"] || "0");
                        if (size > 0 && size <= MAX_SIZE_BYTES) { bestVideo = video; break; }
                    } catch {}
                }
                if (!bestVideo?.url) { logWarn("[AutoDown] Bilibili: Video quá lớn hoặc không tìm được link."); return; }

                const rawPath       = path.join(tempDir, `bili_${Date.now()}.mov`);
                const processedPath = path.join(tempDir, `bili_done_${Date.now()}.mov`);
                try {
                    await downloadFile(bestVideo.url, rawPath);
                    await processYouTubeVideo(rawPath, processedPath);
                    const { size } = fs.statSync(processedPath);
                    if (size > MAX_SIZE_BYTES) return;
                    const meta = await getVideoMetadata(processedPath);
                    await sendVideo(api, processedPath, threadId, threadType, {
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐁𝐢𝐥𝐢𝐁𝐢𝐥𝐢\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        thumbnailUrl: data.thumbnail,
                        width: meta.width, height: meta.height, duration: meta.duration * 1000
                    });
                } catch (err) { logWarn(`[AutoDown] Lỗi Bilibili: ${err.message}`); }
                finally { cleanupFiles([rawPath, processedPath], 0); }
                return;
            }

            // ============== YOUTUBE ==============//
            if (source === "youtube" || /youtube\.com|youtu\.be/.test(finalUrl)) {
                const MAX_SIZE_BYTES = 500 * 1024 * 1024;
                const candidates = data.medias.filter(m => m.type?.startsWith("video") && m.url);
                let bestVideo = null;
                for (const video of candidates) {
                    try {
                        const head = await axios.head(video.url, { timeout: 10000 });
                        const size = parseInt(head.headers["content-length"] || "0");
                        if (size > 0 && size <= MAX_SIZE_BYTES) { bestVideo = video; break; }
                    } catch {}
                }
                if (!bestVideo?.url) { logWarn("[AutoDown] YouTube: Video quá lớn hoặc không tìm được link."); return; }

                const rawPath       = path.join(tempDir, `yt_${Date.now()}.mov`);
                const processedPath = path.join(tempDir, `yt_done_${Date.now()}.mov`);
                try {
                    await downloadFile(bestVideo.url, rawPath);
                    await processYouTubeVideo(rawPath, processedPath);
                    const { size } = fs.statSync(processedPath);
                    if (size > MAX_SIZE_BYTES) return;
                    const meta = await getVideoMetadata(processedPath);
                    await sendVideo(api, processedPath, threadId, threadType, {
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐘𝐨𝐮𝐭𝐮𝐛𝐞\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        thumbnailUrl: data.thumbnail,
                        width: meta.width, height: meta.height, duration: meta.duration * 1000
                    });
                } catch (err) { logWarn(`[AutoDown] Lỗi YouTube: ${err.message}`); }
                finally { cleanupFiles([rawPath, processedPath], 0); }
                return;
            }

            // ============== XNXX ==============//
            if (source === "xnxx" || /xnxx\.com/.test(finalUrl)) {
                const MAX_SIZE_BYTES = 100 * 1024 * 1024;
                const candidates = data.medias.filter(m => m.type?.startsWith("video") && m.url);
                let bestVideo = null;
                for (const video of candidates) {
                    try {
                        const head = await axios.head(video.url, { timeout: 10000 });
                        const size = parseInt(head.headers["content-length"] || "0");
                        if (size > 0 && size <= MAX_SIZE_BYTES) { bestVideo = video; break; }
                    } catch {}
                }
                if (!bestVideo?.url) { logWarn("[AutoDown] XNXX: Không tìm được video phù hợp."); return; }

                const rawPath       = path.join(tempDir, `xnxx_${Date.now()}.mov`);
                const processedPath = path.join(tempDir, `xnxx_done_${Date.now()}.mov`);
                try {
                    await downloadFile(bestVideo.url, rawPath);
                    await processYouTubeVideo(rawPath, processedPath);
                    const { size } = fs.statSync(processedPath);
                    if (size > MAX_SIZE_BYTES) return;
                    const meta = await getVideoMetadata(processedPath);
                    await sendVideo(api, processedPath, threadId, threadType, {
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐗𝐧𝐱𝐱\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        thumbnailUrl: data.thumbnail,
                        width: meta.width, height: meta.height, duration: meta.duration * 1000
                    });
                } catch (err) { logWarn(`[AutoDown] Lỗi XNXX: ${err.message}`); }
                finally { cleanupFiles([rawPath, processedPath], 0); }
                return;
            }

            // ============== XVIDEOS ==============//
            if (source.includes("xvideos") || /xvideos\.com/.test(finalUrl)) {
                const MAX_SIZE_BYTES = 100 * 1024 * 1024;
                const candidates = data.medias.filter(m => m.type?.startsWith("video") && m.url);
                let bestVideo = null;
                for (const video of candidates) {
                    try {
                        const head = await axios.head(video.url, { timeout: 10000 });
                        const size = parseInt(head.headers["content-length"] || "0");
                        if (size > 0 && size <= MAX_SIZE_BYTES) { bestVideo = video; break; }
                    } catch {}
                }
                if (!bestVideo?.url) return;

                const rawPath       = path.join(tempDir, `xv_${Date.now()}.mov`);
                const processedPath = path.join(tempDir, `xv_done_${Date.now()}.mov`);
                try {
                    await downloadFile(bestVideo.url, rawPath);
                    await processYouTubeVideo(rawPath, processedPath);
                    const { size } = fs.statSync(processedPath);
                    if (size > MAX_SIZE_BYTES) return;
                    const meta = await getVideoMetadata(processedPath);
                    await sendVideo(api, processedPath, threadId, threadType, {
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐗𝐯𝐢𝐝𝐞𝐨𝐬\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        thumbnailUrl: data.thumbnail,
                        width: meta.width, height: meta.height, duration: meta.duration * 1000
                    });
                } catch (err) { logWarn(`[AutoDown] Lỗi Xvideos: ${err.message}`); }
                finally { cleanupFiles([rawPath, processedPath], 0); }
                return;
            }

            // ============== SOUNDCLOUD ==============//
            if (source === "soundcloud" || /soundcloud\.com/.test(finalUrl)) {
                const audio = data.medias.find(m => m.type === "audio");
                if (!audio?.url) return;

                const tempPath   = path.join(tempDir, `sc_${Date.now()}`);
                const aacPath    = `${tempPath}.aac`;
                const attachments = [];
                try {
                    await downloadFile(audio.url, tempPath);
                    await convertToAac(tempPath, aacPath);
                    if (data.thumbnail) {
                        const imagePath = path.join(tempDir, `scimg_${Date.now()}.jpg`);
                        await downloadFile(data.thumbnail, imagePath);
                        attachments.push(imagePath);
                    }
                    await api.sendMessage({
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐒𝐨𝐮𝐧𝐝𝐂𝐥𝐨𝐮𝐝\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        attachments, ttl: 500_000
                    }, threadId, threadType);
                    await sendVoice(api, aacPath, threadId, threadType);
                } catch (err) { logWarn(`[AutoDown] Lỗi SoundCloud: ${err.message}`); }
                finally { cleanupFiles([tempPath, aacPath, ...attachments]); }
                return;
            }

            // ============== MIXCLOUD ==============//
            if (source === "mixcloud" || /mixcloud\.com/.test(finalUrl)) {
                const audio = data.medias.find(m => m.type === "audio");
                if (!audio?.url) return;

                const tempPath   = path.join(tempDir, `mc_${Date.now()}`);
                const aacPath    = `${tempPath}.aac`;
                const attachments = [];
                try {
                    await downloadFile(audio.url, tempPath);
                    await convertToAac(tempPath, aacPath);
                    if (data.thumbnail) {
                        const imagePath = path.join(tempDir, `mcimg_${Date.now()}.jpg`);
                        await downloadFile(data.thumbnail, imagePath);
                        attachments.push(imagePath);
                    }
                    await api.sendMessage({
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐌𝐢𝐱𝐂𝐥𝐨𝐮𝐝\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        attachments, ttl: 500_000
                    }, threadId, threadType);
                    await sendVoice(api, aacPath, threadId, threadType);
                } catch (err) { logWarn(`[AutoDown] Lỗi MixCloud: ${err.message}`); }
                finally { cleanupFiles([tempPath, aacPath, ...attachments]); }
                return;
            }

            // ============== SPOTIFY ==============//
            if (source === "spotify" || /spotify\.com/.test(finalUrl)) {
                const audio = data.medias.find(m => m.type === "audio");
                if (!audio?.url) return;

                const tempPath   = path.join(tempDir, `sp_${Date.now()}`);
                const aacPath    = `${tempPath}.aac`;
                const attachments = [];
                try {
                    await downloadFile(audio.url, tempPath);
                    await convertToAac(tempPath, aacPath);
                    if (data.thumbnail) {
                        const imagePath = path.join(tempDir, `spimg_${Date.now()}.jpg`);
                        await downloadFile(data.thumbnail, imagePath);
                        attachments.push(imagePath);
                    }
                    await api.sendMessage({
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐒𝐩𝐨𝐭𝐢𝐟𝐲\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        attachments, ttl: 500_000
                    }, threadId, threadType);
                    await sendVoice(api, aacPath, threadId, threadType);
                } catch (err) { logWarn(`[AutoDown] Lỗi Spotify: ${err.message}`); }
                finally { cleanupFiles([tempPath, aacPath, ...attachments]); }
                return;
            }

            // ============== ZINGMP3 ==============//
            if (source === "zingmp3" || /zingmp3\.vn/.test(finalUrl)) {
                const audio = data.medias.find(m => m.type === "audio");
                if (!audio?.url) return;

                const tempPath   = path.join(tempDir, `zing_${Date.now()}`);
                const aacPath    = `${tempPath}.aac`;
                const attachments = [];
                try {
                    await downloadFile(audio.url, tempPath);
                    await convertToAac(tempPath, aacPath);
                    if (data.thumbnail) {
                        const imagePath = path.join(tempDir, `zingimg_${Date.now()}.jpg`);
                        await downloadFile(data.thumbnail, imagePath);
                        attachments.push(imagePath);
                    }
                    await api.sendMessage({
                        msg: `/-li 𝐀𝐮𝐭𝐨𝐃𝐨𝐰𝐧: 𝐙𝐢𝐧𝐠𝐌𝐏𝟑\n📄 𝐓𝐢𝐭𝐭𝐥𝐞: ${mediaTitle}\n👤 𝐀𝐮𝐭𝐡𝐨𝐫: ${author}`,
                        attachments, ttl: 500_000
                    }, threadId, threadType);
                    await sendVoice(api, aacPath, threadId, threadType);
                } catch (err) { logWarn(`[AutoDown] Lỗi ZingMP3: ${err.message}`); }
                finally { cleanupFiles([tempPath, aacPath, ...attachments]); }
                return;
            }

        } catch (err) {
            logWarn(`[AutoDown] Lỗi xử lý: ${err.message}`);
        }
    });
}

module.exports = { startAutoDown };
